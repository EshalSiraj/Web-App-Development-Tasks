

//6
let score = prompt("Enter student score:");

if (score >= 90) {
    console.log("Grade: A+");
} else if (score >= 80) {
    console.log("Grade: A");
} else if (score >= 70) {
    console.log("Grade: B");
} else if (score >= 60) {
    console.log("Grade: C");
} else if (score >= 50) {
    console.log("Grade: D");
} else {
    console.log("Grade: F (Fail)");
}


/*
//5
let num = prompt("Enter a number:");

if (num % 3 === 0) {
    console.log(num ,"is a multiple of 3.");
} else {
    console.log(num, "is not a multiple of 3.");
}


 //4
let a = 10;

console.log("Initial value of a:", a);

console.log("Post-increment (a++):", a++); 
console.log("After post-increment, a:", a);
console.log("Pre-increment (++a):", ++a); 

console.log("Post-decrement (a--):", a--); 
console.log("After post-decrement, a:", a);
console.log("Pre-decrement (--a):", --a); 




//3
const instagramProfile = {
    username: "eshal.siraj",
    name: "eshal",
    posts: 0,
    followers: 86,
    following: 227,
    bio: "", 
    profilePicture: "imagesJS/pfp.png", 
    isPrivate: true, 
};

console.log(instagramProfile);

 //2
const Product = {
    name: "Wheel Entine",
    brand: "Auto store",
    description: "PAKWHEELS WATERLESS AND GLASS CLEANER",
    priceBefore:1198,
    priceAfter:958,
    discount: "20%",
};

console.log(Product);


 // 1
let Value = 123456789012345678901234567890n; 
let Value1 = Symbol("id"); 

console.log("Type of bigIntValue:", typeof Value); 
console.log("Type of symbolValue:", typeof Value1); 



*/
