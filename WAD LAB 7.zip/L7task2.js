
const containers = document.querySelectorAll(".container");

for (let i = 0; i < containers.length; i++) {
  containers[i].innerText = " container  " + (i + 1);
}


