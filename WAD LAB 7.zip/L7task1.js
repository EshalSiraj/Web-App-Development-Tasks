
const heading = document.createElement("h1");
const yourName = "Eshal"; 
const regNo = "54686"; 

heading.innerText = "Web App Development " + yourName +" "+ regNo;
document.body.appendChild(heading);
