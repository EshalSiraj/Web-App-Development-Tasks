 // Task 1
 const toggleBtn = document.getElementById("Btn");

 toggleBtn.onclick = () => {
   document.body.classList.toggle("dark-mode");
 };

 // Task 2
 toggleBtn.onmouseover = () => {
   toggleBtn.style.backgroundColor = "darkorange";
 };

 