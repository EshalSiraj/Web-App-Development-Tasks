/*
// 1
function findEvenNumbers(arr) {
    let evenNumbers = [];
    for (let num of arr) {
        if (num % 2==0) {
            evenNumbers.push(num);
        }
    }
    return evenNumbers;
}
let array=[1, 2, 3, 4, 5, 6,7,8,9,10];
console.log(findEvenNumbers(array)); 


// 2
function findMaxMin(arr) {
    let max = arr[0];
    let min = arr[0];
    for (let num of arr) {
        if (num > max) max = num;
        if (num < min) min = num;
    }
    return { max, min };
}
console.log(findMaxMin([3, 1, 7, 5, 9, 2])); 

// 3
function convertToUpperCase(arr) {
    let upperCaseArray = [];
    for (let str of arr) {
        upperCaseArray.push(str.toUpperCase());
    }
    return upperCaseArray;
}
console.log(convertToUpperCase(["hello", "world"])); 

// 4
function modifySoftwareHouses() {
    let softwareHouses = ["Microsoft", "Google", "Apple", "Amazon", "Facebook"];
    softwareHouses.shift(); 
    softwareHouses.splice(2, 1, "Tesla"); 
    softwareHouses.push("Netflix"); 
    return softwareHouses;
}
console.log(modifySoftwareHouses()); 

// 5
function countVowels(str) {
    let vowels = "aeiouAEIOU";
    let count = 0;
    for (let char of str) {
        if (vowels.includes(char)) {
            count++;
        }
    }
    return count;
}
console.log(countVowels("hello world")); 

// 6
const countVowelsArrow = (str) => {
    return str.split('').filter(char => "aeiouAEIOU".includes(char)).length;
};
console.log(countVowelsArrow("programming")); 

// 7
function printSquares(arr) {
    arr.forEach(num => console.log(num * num));
}
printSquares([2,3,4]); 

// 8
function filterHighScorers(marks) {
    return marks.filter(mark => mark >50);
}
console.log(filterHighScorers([45,60,75,30,90])); 

// 9
function createArrayFromUserInput(n) {
    let arr =[];
    for (let i =1; i <=n; i++) {
        arr.push(i);
    }
    return arr;
}
let n=prompt("Enter Number of elements for array");

console.log(createArrayFromUserInput(n)); 

*/



// 10
function product(arr) {
    return arr.reduce((product, num) => product * num, 1);
}
console.log(product([2, 3, 4]));



