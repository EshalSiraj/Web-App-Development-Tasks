//Task 1
const div = document.getElementById("Div1");

console.log("Old class:", div.getAttribute("class"));
div.setAttribute("class", "DivNewClass");
console.log("New class:", div.getAttribute("class"));

//Task 2
const Button = document.createElement("button");
Button.innerText = "logIn";
Button.style.color = "white";
Button.style.backgroundColor = "black";
document.documentElement.insertBefore(Button, document.body);

//Task 3
const para = document.getElementById("Paragraph");
para.classList.add("newStyling");
console.log("Classes after appending:", para.className);











